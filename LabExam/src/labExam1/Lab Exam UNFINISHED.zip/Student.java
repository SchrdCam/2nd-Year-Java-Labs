package labExam1;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a student, based on their student number and a list of time slots
 * where they have a commitment.
 */
public class Student {

	/**
	 * Creates a new Student object based on the input parameters.
	 * 
	 * @param number
	 *            The student number
	 * @param slotSpecs
	 *            A list of time-slot specifications
	 */
	private String studentNumber;
	public List<TimeSlot> slotSpecs = new ArrayList<TimeSlot>();

	public Student(String number, List<String> slotSpecs) {
		this.studentNumber = number;
		for (String slot : slotSpecs) {
			this.slotSpecs.add(new TimeSlot(slot));
		}
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public List<TimeSlot> getSlotSpecs() {
		return slotSpecs;
	}

	public List<String> getLabGroups(Course course) {
		List<LabGroup> groups = course.getLabGroups();
		List<String> elegibles = new ArrayList<String>();
		for (LabGroup lab : groups) {
			if (elegibles.contains(lab.getGroup())) {
				continue;
			}
			boolean noCommit = true;
			for (int d=0;d<slotSpecs.size();d++) {
				if(slotSpecs.get(d).getDay().equals(lab.gettSlot().getDay())) {
					noCommit =false;
					break;
				}
			}
			if (noCommit) {
				elegibles.add(lab.getGroup());
				break;
			}
			for (TimeSlot tSlot : slotSpecs) {
				if (lab.gettSlot().getDay().equals(tSlot.getDay())) {
					if (lab.gettSlot().getEndTime().equals(tSlot.getStrtTime())
							|| (lab.gettSlot().getStrtTime().equals(tSlot.getEndTime()))) {
						elegibles.add(lab.getGroup());
					} else if (!lab.gettSlot().equals(tSlot) && !intersect(lab.gettSlot(), tSlot)) {
						elegibles.add(lab.getGroup());
					}
				}
			}
		}		return elegibles;
	}

	private boolean intersect(TimeSlot lab, TimeSlot act) {
		int labStart = lab.getStrtTime().getHour();
		int labEnd = lab.getEndTime().getHour();
		int actStart = act.getStrtTime().getHour();
		int actEnd = act.getEndTime().getHour();
		if ((actStart >= labStart && actStart <= labEnd) || (actEnd >= labStart && actEnd <= labEnd)) {
			return true;
		} else {
			return false;
		}
	}
}